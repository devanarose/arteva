import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/categoriesss_item.dart';
import '../models/product_item.dart';

class DBHelper{
  static final DBHelper instance = DBHelper._();
  static Database? _database;

  DBHelper._();

  Future<Database> get db async{
    _database ??= await _initDb();
    return _database!;
  }

  Future<Database> _initDb() async{
    final path = join(await getDatabasesPath(),'arteva.db');
    return await openDatabase(path,version:2,onCreate: _onCreate,onUpgrade: _onUpgrade);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products(
        p_id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        imageUrl TEXT,
        subtitle TEXT,
        description TEXT,
        c_id TEXT,
        price REAL,
        section TEXT
      )
    ''');

    await db.execute('''
    CREATE TABLE categories(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      c_name TEXT NOT NULL,
      imagePath TEXT
    )
  ''');
  }

  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('ALTER TABLE products ADD COLUMN section TEXT');
    }
  }

  /// category

  Future<int> insertCategory(CategoriesssItem category) async {
    final dbClient = await db;
    return await dbClient.insert('categories', category.toMap());
  }

  Future<List<CategoriesssItem>> getAllCategories() async {
    final dbClient = await db;
    final maps = await dbClient.query('categories');
    return maps.map((map) => CategoriesssItem.fromMap(map)).toList();
  }

  Future<int> updateCategory(CategoriesssItem category) async {
    final dbClient = await db;
    return await dbClient.update('categories', category.toMap(), where: 'id = ?', whereArgs: [category.id],);
  }

  Future<int> deleteCategory(int id) async {
    final dbClient = await db;
    return await dbClient.delete('categories', where: 'id = ?', whereArgs: [id]);
  }


  ///product

  Future<int> insertProduct(ProductItem product) async {
    final dbClient = await db;
    return await dbClient.insert('products', product.toMap());
  }

  Future<ProductItem?> getProductById(String id) async {
    final dbClient = await db;
    final maps = await dbClient.query('products', where: 'p_id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      return ProductItem.fromMap(maps.first);
    }
    return null;
  }

  Future<List<ProductItem>> getAllProducts() async {
    final dbClient = await db;
    final List<Map<String, dynamic>> maps = await dbClient.query('products');
    return maps.map((map) => ProductItem.fromMap(map)).toList();
  }
  Future<int> updateProduct(ProductItem product) async {
    final dbClient = await db;
    return await dbClient.update('products', product.toMap(), where: 'p_id = ?', whereArgs: [product.p_id],);
  }
  Future<int> deleteProduct(int id) async {
    final dbClient = await db;
    return await dbClient.delete('products', where: 'p_id = ?', whereArgs: [id]);
  }
}